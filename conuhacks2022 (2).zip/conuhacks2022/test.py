import os
print(os.environ['secretUser'])