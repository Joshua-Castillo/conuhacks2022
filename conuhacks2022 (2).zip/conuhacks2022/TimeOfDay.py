class TimeOfDay:
    def __init__(self):
        self.night=0
        self.day=0
        self.townhall=0

    def setNight(self,value):
        self.night=value
    def setDay(self, value):
        self.day=value
    def setTownhall(self,value):
        self.townhall=value

