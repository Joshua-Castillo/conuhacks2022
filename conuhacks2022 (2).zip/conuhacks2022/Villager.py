class Villager: 
    def __init__(self):
        self.vote=0
    def setVote(self,value):
        self.vote=value
        