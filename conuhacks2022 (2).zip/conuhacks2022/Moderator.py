class Moderator: 
    def __init__(self, day, night, townhall):
        self.day=0
        self.night=0
        self.townhall=0
    def setDay(self,value):
        self.day=value
    def setNight(self,value):
        self.night=value
    def setTownhall(self,value):
        self.townhall=value